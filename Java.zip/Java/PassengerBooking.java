import java.util.Scanner;

public class PassengerBooking {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[][] passengers = new String[5][3];
        int count = 0;

        while (count < 5) {
            System.out.println("\nEnter Passenger Name:");
            passengers[count][0] = sc.next();

            System.out.println("Enter Seat Number:");
            passengers[count][1] = sc.next();

            System.out.println("Enter Class (Economy/Business):");
            passengers[count][2] = sc.next();

            count++;

            System.out.println("Do you want to add another passenger? (yes/no)");
            String option = sc.next();
            if (option.equalsIgnoreCase("no"))
                break;
        }

        System.out.println("\n--- Passenger Booking List ---");
        System.out.println("Name\tSeat\tClass");

        for (int i = 0; i < count; i++) {
            System.out.println(passengers[i][0] + "\t" + passengers[i][1] + "\t" + passengers[i][2]);
        }

        sc.close();
    }
}
