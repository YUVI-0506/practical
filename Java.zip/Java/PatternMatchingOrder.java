import java.util.Scanner;

public class PatternMatchingOrder {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Customer Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Item Code: ");
        String code = sc.nextLine();

        if (name.matches("[A-Za-z ]+"))
            System.out.println("Valid Name");
        else
            System.out.println("Invalid Name");

        if (code.matches("[A-Z]{3}[0-9]{3}"))
            System.out.println("Valid Item Code");
        else
            System.out.println("Invalid Item Code");

        sc.close();
    }
}
