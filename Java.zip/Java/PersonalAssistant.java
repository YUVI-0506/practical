import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class PersonalAssistant {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Personal Assistant");
        JTextField taskField = new JTextField();
        JButton addButton = new JButton("Add Task");
        JTextArea taskArea = new JTextArea();
        JScrollPane scroll = new JScrollPane(taskArea);

        ArrayList<String> tasks = new ArrayList<>();

        frame.setSize(400, 400);
        frame.setLayout(null);

        taskField.setBounds(20, 20, 250, 30);
        addButton.setBounds(280, 20, 90, 30);
        scroll.setBounds(20, 70, 350, 270);

        frame.add(taskField);
        frame.add(addButton);
        frame.add(scroll);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String task = taskField.getText();
                tasks.add(task);
                taskArea.append(task + "\n");
                taskField.setText("");
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
