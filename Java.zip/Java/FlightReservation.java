import java.util.Scanner;

public class FlightReservation {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int seats = 5;
        int choice;

        do {
            System.out.println("\n--- Flight Reservation System ---");
            System.out.println("1. Book Ticket");
            System.out.println("2. Cancel Ticket");
            System.out.println("3. Check Available Seats");
            System.out.println("4. Exit");
            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            if (choice == 1) {
                if (seats > 0) {
                    seats--;
                    System.out.println("Ticket Booked Successfully!");
                } else {
                    System.out.println("No Seats Available!");
                }
            } else if (choice == 2) {
                if (seats < 5) {
                    seats++;
                    System.out.println("Ticket Cancelled Successfully!");
                } else {
                    System.out.println("No Tickets to Cancel!");
                }
            } else if (choice == 3) {
                System.out.println("Available Seats: " + seats);
            } else if (choice == 4) {
                System.out.println("Thank You!");
            } else {
                System.out.println("Invalid Choice");
            }

        } while (choice != 4);

        sc.close();
    }
}
