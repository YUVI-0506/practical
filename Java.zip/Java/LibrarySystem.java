import java.util.Scanner;

public class LibrarySystem {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Category Number (1-4): ");
        int category = sc.nextInt();

        if (category >= 1 && category <= 4) {

            switch (category) {
                case 1:
                    System.out.println("Category: Science");
                    System.out.println("Available Books: Physics, Chemistry, Biology");
                    break;

                case 2:
                    System.out.println("Category: Literature");
                    System.out.println("Available Books: Novels, Poems, Stories");
                    break;

                case 3:
                    System.out.println("Category: Technology");
                    System.out.println("Available Books: Java, Python, AI");
                    break;

                case 4:
                    System.out.println("Category: History");
                    System.out.println("Available Books: World History, Indian History");
                    break;
            }

        } else {
            System.out.println("Invalid Category Number");
        }

        sc.close();
    }
}
