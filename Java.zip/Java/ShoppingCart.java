import java.text.NumberFormat;
import java.util.Scanner;

public class ShoppingCart {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter item price: ");
        double price = sc.nextDouble();

        System.out.print("Enter quantity: ");
        int qty = sc.nextInt();

        double total = price * qty;
        double tax = total * 0.18;
        double finalPrice = total + tax;

        NumberFormat nf = NumberFormat.getCurrencyInstance();

        System.out.println("\n--- Bill Summary ---");
        System.out.println("Total Cost: " + nf.format(total));
        System.out.println("Tax (18%): " + nf.format(tax));
        System.out.println("Final Price: " + nf.format(finalPrice));

        sc.close();
    }
}
