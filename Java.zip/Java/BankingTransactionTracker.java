import java.util.Scanner;

public class BankingTransactionTracker {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        StringBuilder[] transactions = new StringBuilder[10];
        int count = 0;

        while (count < 10) {
            System.out.println("\nEnter Customer Name:");
            String name = sc.next();

            System.out.println("Enter Transaction Type (Deposit/Withdraw):");
            String type = sc.next();

            System.out.println("Enter Amount:");
            String amount = sc.next();

            transactions[count] = new StringBuilder();
            transactions[count].append(name + " - " + type + " - Rs." + amount);
            count++;

            System.out.println("Do you want to add another transaction? (yes/no)");
            String option = sc.next();
            if (option.equalsIgnoreCase("no"))
                break;
        }

        System.out.println("\nEnter name to search transaction:");
        String searchName = sc.next();
        boolean found = false;

        for (int i = 0; i < count; i++) {
            if (transactions[i].toString().toLowerCase().startsWith(searchName.toLowerCase())) {
                System.out.println(transactions[i]);
                found = true;
            }
        }

        if (!found)
            System.out.println("No transaction found for given name");

        sc.close();
    }
}
